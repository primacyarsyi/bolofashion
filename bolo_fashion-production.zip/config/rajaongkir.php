<?php

/**
 * config rajaongkir
 */

return [
    'api_key' => env('RAJAONGKIR_API_KEY')
];